# Framework trial results

**The candidate did not meet the predeclared nondecreasing aggregate required-finding coverage gate.** Preserve this result; no weak response was coached, retried or replaced. All 32 planned fresh-agent first responses completed (8 cases × 2 conditions × 2 repeats).

| Case | Baseline met/applicable | Candidate met/applicable |
|---|---:|---:|
| E13 — wording scope | 8/10 | 8/10 |
| E15 — expert density | 12/12 | 12/12 |
| E19 — hidden validation | 11/14 | 11/14 |
| E23 — invalid/unsupported profiles | 20/20 | 20/20 |
| E34 — pending work | 14/14 | 12/14 |
| E35 — recognition discovery | 21/24 | 22/23 |
| F01 — quick review routing | 8/8 | 8/8 |
| F02 — screenshot-only evidence | 8/8 | 8/8 |
| **Total** | **102/110 (92.73%)** | **101/109 (92.66%)** |

Both conditions missed eight applicable findings. One candidate E35 response received a justified N/A for combined-filter verification because it proposed metadata browsing rather than additional filtering controls. Excluding that conditional criterion from all four E35 responses yields a common-denominator sensitivity comparison of 102/108 baseline versus 101/108 candidate; the direction remains unchanged.

The condition-specific regression is candidate E34 repeat 1 (`response-19.md`, blind B03): it preserved draft, identity, filters and local view but did not recommend usable focus continuity or a focus-continuity check. Baseline covered both in both repeats. Candidate gained one narrow-layout-check finding in E35. The small overall difference is a literal acceptance-gate result, not evidence of a statistically reliable deterioration or intended-user benefit.

Shared omissions remain actionable: all E13 responses omitted a proposed actual-effect check despite checking expected meaning; all E19 responses stopped the correction sequence before completing/retrying saving within verified boundaries; one response in each condition omitted a tab/disclosure error marker; three E35 responses proposed narrowing controls without a conditional combined-filter check. Baseline E35 repeat 1 also omitted narrow-layout checking. Every response-specific omission and reason is retained in `assessment.json` and `assessment.md`.

| Other measure | Baseline | Candidate |
|---|---:|---:|
| Review-only mode adherence | 16/16 | 16/16 |
| Unsupported claims identified | 0 | 0 |
| Unnecessary changes identified | 0 | 0 |
| Hard rejection triggers identified | 0 | 0 |
| Total whitespace word count | 4,555 | 4,548 |
| Mean words/response | 284.69 | 284.25 |
| Median words/response | 271.5 | 270 |
| Range | 127–432 | 114–445 |

No response claimed unauthorized edits, fabricated interface checks, mandatory option limits or a false whole-product passing verdict. Two candidate F02 responses used a narrowly qualified Pass for text accompanying green; the blind reviewer accepted that supported observation and did not treat it as evidence of accessibility, persistence or shipping readiness.

The assessor was a fresh child agent reading randomized condition-masked copies and the rubric/procedure, without the condition key or source skill files. It fixed per-case criteria before assigning scores, but had read the first eight blind texts before recording that list. The generator/coordinator knew conditions; prose style/document mentions could expose clues. This is one model review with partial masking, not independent double-blind evaluation. Source reference quotations/line numbers were not independently authenticated by the assessor. There are two responses per cell; no confidence interval or generalization is justified.

All seven supplied source hashes were unchanged throughout generation. Exact model version, sampling parameters, tokens and per-run duration are unknown. Prompts, source snapshots, raw first final responses, source/input hashes, capture timestamps, word counts, blind copies, private mapping, assessment and decoded scores are preserved here. Original local links remain in raw responses; only blind copies normalize guide path prefixes. No application tests or intended-user sessions were conducted by these trials.
