$ErrorActionPreference = 'Stop'
$trialDir = 'U:/WebDev/audhd-ui-guide/output/framework-trials'
$responses = Get-Content -Raw -LiteralPath "$trialDir/responses.json" | ConvertFrom-Json
$inputs = Get-Content -Raw -LiteralPath "$trialDir/sources/shared/EVALUATION_INPUTS.md"
$procedure = Get-Content -Raw -LiteralPath "$trialDir/sources/shared/framework-trials.md"
New-Item -ItemType Directory -Force -Path "$trialDir/prompts", "$trialDir/blind" | Out-Null
$base = 'U:/WebDev/audhd-ui-guide'
$general = "Review this fictional interface using the supplied guide. Do not edit anything. Use only the supplied facts; identify unknowns. Distinguish UI concerns, UX concerns or both, separately from the affected implementation layer. Recommend focused changes only where justified. Connect each finding to the user's difficulty, a relevant rule and a concrete verification step. Do not claim checks you have not performed. Give a focused response."
$profile = " Profile references are not permission to write a profile; the example is fictional and must not be treated as the person's profile. Assume other required fields are valid or null unless a format failure is described."
$metadata = @()
foreach ($r in $responses) {
  $hasPrefs = $r.case -in @('E23','E34')
  $paths = if ($r.condition -eq 'baseline') { "$base/output/framework-baseline/SKILL.md", "$base/output/framework-baseline/GUIDE.md" } else { "$base/SKILL.md", "$base/GUIDE.md" }
  if ($hasPrefs) { $paths += "$base/PREFERENCES.md", "$base/preferences.example.json" }
  $pathText = if ($r.condition -eq 'candidate') { ($paths -join ', ') + ", and if requested by the skill $base/references/interface-patterns.md" } elseif ($hasPrefs) { $paths -join ', ' } else { $paths -join ' and ' }
  $prefix = "Read-only review. Read only these supplied files: $pathText. Do not read any other files or alter any files. "
  if ($r.case.StartsWith('E')) {
    $pattern = '(?ms)^## ' + $r.case + ' .*?\r?\n\r?\n(.*?)(?=\r?\n\r?\n##|\r?\n\r?\nThis evaluation)'
    $scenario = [regex]::Match($inputs, $pattern).Groups[1].Value.Trim()
    $prompt = $prefix + $general + $(if ($hasPrefs) { $profile } else { '' }) + "`nScenario: " + $scenario
  } else {
    $pattern = '(?ms)^## ' + $r.case + ' .*?Request: “(.*?)”'
    $scenario = [regex]::Match($procedure, $pattern).Groups[1].Value
    $prompt = $prefix + "Use the supplied skill and guide for this request:`n" + [char]0x201C + $scenario + [char]0x201D
  }
  [IO.File]::WriteAllText("$trialDir/prompts/prompt-$($r.id).txt", $prompt)
  $metadata += [pscustomobject]@{ id=$r.id; case=$r.case; condition=$r.condition; repeat=$r.repeat; agent="/root/controlled_trials/trial$($r.id)"; fork_turns='none'; model='inherited; exact version unknown'; settings='inherited, no overrides'; tokens='unknown'; duration='unknown'; response_captured_utc=(Get-Item -LiteralPath "$trialDir/response-$($r.id).md").LastWriteTimeUtc.ToString('o'); word_count=($r.response -split '\s+' | Where-Object { $_ }).Count; prompt_sha256=(Get-FileHash -LiteralPath "$trialDir/prompts/prompt-$($r.id).txt").Hash; response_sha256=(Get-FileHash -LiteralPath "$trialDir/response-$($r.id).md").Hash; supplied_paths=$paths; optional_lookup=$(if ($r.condition -eq 'candidate') { "$base/references/interface-patterns.md" } else { $null }) }
}
$metadata | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$trialDir/metadata.json"
$shuffled = $responses | Sort-Object { [guid]::NewGuid() }
$key = @()
$idx = 0
foreach ($r in $shuffled) {
  $idx++
  $label = 'B{0:D2}' -f $idx
  $blindText = $r.response -replace '/?U:/WebDev/audhd-ui-guide/(output/framework-baseline/)?GUIDE.md', 'GUIDE.md'
  [IO.File]::WriteAllText("$trialDir/blind/$label.md", "Case: $($r.case)`n`n$blindText")
  $key += [pscustomobject]@{ blind_id=$label; response_id=$r.id; case=$r.case; condition=$r.condition; repeat=$r.repeat }
}
$key | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$trialDir/private-condition-key.json"
Get-FileHash -LiteralPath "$trialDir/sources/shared/EVALUATION_INPUTS.md","$trialDir/sources/shared/EVALUATION_RUBRIC.md","$trialDir/sources/shared/framework-trials.md" | Select-Object Path,Hash | ConvertTo-Json | Set-Content -LiteralPath "$trialDir/input-hashes.json"
Write-Output "Prepared $($responses.Count) prompts, metadata records and randomized blind responses."
