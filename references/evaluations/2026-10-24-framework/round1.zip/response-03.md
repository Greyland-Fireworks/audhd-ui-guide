Replace **“Apply”** with **“Save settings for future reports.”**

The existing label leaves the action’s effect unclear; the replacement states both saving and scope, matching the supplied verified behavior. This is **both a UI concern** (button wording) **and a UX concern** (predicting the outcome). The affected implementation layer is **wording**, with no behavior change justified. Relevant rule: **AUDHD-04 — name actions by their effect**.

**Verification pending:** Inspect the replacement in the rendered form for clipping and a matching accessible name; ask whether a reader understands that existing reports will remain unchanged. No interface or user checks were performed. The surrounding copy and layout are unknown, and no additional changes are justified by the supplied facts.
