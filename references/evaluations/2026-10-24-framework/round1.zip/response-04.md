Replace **“Apply”** with **“Save settings for future reports.”**

- **Finding — Fail:** “Apply” does not identify the supplied, verified effect, leaving users to infer whether existing reports will change. The proposed label names both saving and its future scope. This is **both UI and UX**; the affected implementation layer is **wording**, under **AUDHD-04**.
- **Verification — Pending:** Inspect the rendered button and its accessible name for the new wording; check that the longer label fits at narrow widths and enlarged text. Ask a reader what the action will do before clicking.
- **Evidence limit:** This review used the supplied description and guide. No interface or runtime checks were performed. Surrounding wording and layout are unknown; no additional changes are justified by the supplied facts.

No files were edited.
