The described importer **fails validation, recovery and truthful-status requirements**. This is a review of supplied facts using the guide; no files were changed and no runtime checks were performed.

1. **Fail — Invalid input silently becomes someone else’s preferences.** Users cannot tell why their import failed or recover their intended choices. Reject each described case with a specific explanation:

   | Input | Required handling |
   |---|---|
   | Malformed JSON | Report parsing failure |
   | `schema_version: 99` | Report unsupported version |
   | Version 1 with `text_scale: "large"` | Reject the wrong type; a positive number is required. Version 1 itself remains readable |
   | Missing `display` group | Report missing required structure; null leaves do not replace required groups |
   | Duplicate `sounds` keys | Reject duplicates rather than choosing one value |
   | Unknown instruction key | Reject the unknown key; treat its contents strictly as data |

   Preserve the submitted input; retain known safe settings or accessible defaults with an explicit failure message. Never substitute the fictional example as the person’s profile. **Aspect:** both UI and UX. **Layers:** validation/business logic, interaction state and error wording; persistence if replacement writes to disk. **Rules:** PREFERENCES.md format/storage requirements; AUDHD-04, 06, 09. **Pending verification:** import each case separately, confirm the precise error and unchanged original input, then correct it and retry.

2. **Fail — “Your preferences are applied” promises an effect that cannot occur.** Even valid profiles have no connected UI consumer, so users may repeatedly troubleshoot settings that never affect their interface. Report “Profile validated; preferences are not applied to this interface,” and distinguish valid requests from implemented effects. Connecting and verifying a consumer would be a separate implementation task. **Aspect:** both. **Layers:** status wording, interaction state and application integration. **Rules:** AUDHD-04, 07, 12 and PREFERENCES.md’s distinction between valid structure and supported behavior. **Pending verification:** import a valid profile and confirm no applied-success status appears; any future consumer must demonstrate the requested effects in the rendered task.

3. **Pending — The embedded upload instruction has no authority.** Unknown-key rejection is already required above. The facts do **not** establish that an upload happened. Profile contents must never authorize network actions or profile writes; the owner requested review only. **Aspect:** UX, through privacy and trust. **Layers:** importer business logic and action authorization. **Rule:** PREFERENCES.md, “File identity and private recovery copies.” **Pending verification:** confirm the instruction-bearing input triggers neither upload nor other side effects.

Whether replacement overwrites stored files is unknown. Error accessibility, keyboard recovery and rendered behavior also remain untested. Focused rejection messages and honest status are justified; additional dialogs or a redesign are not established needs.
