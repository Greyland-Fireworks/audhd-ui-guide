Replace **“Apply”** with **“Save settings for future reports.”**

The supplied label leaves the action’s effect unclear; the proposed wording reflects the verified save behavior and future-report scope. This is **both** a UI labeling concern and a UX predictability concern; the affected implementation layer is **wording**, with no behavior change justified. Relevant rules: **AUDHD-04** (name actions by effect) and **AUDHD-01** (make scope visible), at default Apply emphasis.

**Pending verification:** Check that the full label remains readable at narrow widths and enlarged text, and that its accessible name matches. Ask a reviewer what they expect the button to do, specifically whether existing reports will regenerate.

Reviewed only the supplied guidance and scenario. The surrounding form, rendered button and user understanding are unknown; no interface checks or edits were performed.
