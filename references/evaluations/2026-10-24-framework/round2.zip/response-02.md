Replace **“Apply”** with **“Save settings for future reports.”**

“Apply” does not identify the verified save effect or its scope, making the result harder to predict. This is **both** a UI concern (ambiguous label) and a UX concern (understanding the action’s consequence); the affected implementation layer is **wording**, not persistence or business logic. The recommendation follows **AUDHD-04**, with future-report scope supported by **AUDHD-01**. Default emphasis: Apply; primary target: action clarity.

No further changes are justified by the supplied facts.

**Pending verification:** Check that the longer label remains readable and matches the button’s accessible name; ask a reader what clicking it will do, specifically whether existing reports will regenerate. I reviewed only the supplied guidance and scenario; rendered layout, semantics and user understanding remain unknown. No edits or interface tests were performed.
