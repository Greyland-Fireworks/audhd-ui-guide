The justified changes are recognizable item labels, visible search scope and clear separation between filtering and the loaded review. **Adding all four proposed features is not justified.**

This is a review of the supplied scenario against SKILL.md and GUIDE.md only. No files were edited or rendered interactions checked. Applicable rules use default **Apply** emphasis; the focus is discovery and review continuity.

1. **The retained query makes the library appear incomplete.** The described UI hides the restriction and omits a count/reset; the UX consequence is that the returning user cannot reliably discover the other fifteen eligible recordings. Show the retained query, “3 of 18 eligible recordings,” and a clearly scoped “Clear search” action. **Both UI and UX; implementation: wording/layout and interaction state. AUDHD-03.**  
   **Pending verification:** Return with the query retained, inspect the count against eligible records, then clear it and confirm all eighteen become discoverable. Check a zero-result query and its explanation too.

2. **The loaded recording’s absence is unexplained.** The visible note alongside an excluding list leaves its relationship to the current recording unclear. Identify the loaded recording beside the review and explain that it is outside the current search results. Clearing search must preserve its identity, unsaved note and usable focus; opening another recording must remain a separate action. The scenario establishes ambiguity, **not actual draft loss**. **Both UI and UX; implementation: wording/layout and interaction state, with draft-storage behavior unresolved. AUDHD-01, AUDHD-03, AUDHD-05 and AUDHD-10.**  
   **Pending verification:** With an unsaved note, exclude the loaded recording and clear search. Confirm the same recording and unchanged note remain loaded, with predictable keyboard focus.

3. **ID-only names require recall the user does not have.** Display existing map and comparison-purpose metadata as recognizable item descriptions; retain IDs as secondary detail and use dates where helpful for disambiguation. Offer visible map/purpose choices or a browsable list so discovery does not depend on typing an identifier. **Both UI and UX; implementation: wording/layout and discovery interaction state. AUDHD-03 and AUDHD-04.**  
   **Pending verification:** Ask a returning user to locate the recording using only remembered map and purpose, without typing an ID, name or date. Check duplicate descriptions and keyboard/narrow-layout access.

Start with these focused changes. Thumbnails could help if recordings have distinguishable visual content, but require useful text equivalents. Pins need evidence of repeated comparison use; “recently watched” needs evidence that recency helps and an established retention/privacy contract. Autocomplete still requires a starting clue and cannot alone solve recognition-based browsing. None of those needs is established here.

Actual layout, contrast, semantics, keyboard operation, search coverage and draft persistence remain unknown. All proposed interaction and user checks are pending.
