Replace **Apply** with **Save settings for future reports**.

- **Finding — UI and UX; implementation layer: wording.** “Apply” leaves the effect unclear. The supplied verified behavior saves the displayed settings for future reports without regenerating existing reports. The proposed label names that effect, following **AUDHD-04**.
- **Verification — Pending.** Inspect the rendered button for clipping and confirm its accessible name matches. Ask a reader what clicking it will do, including whether existing reports change.

This review used only the supplied scenario and guide; no interface checks or edits were performed. Surrounding wording and layout are unknown. No additional changes are justified by the supplied facts.
