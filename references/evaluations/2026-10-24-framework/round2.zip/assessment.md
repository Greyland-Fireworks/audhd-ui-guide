# Masked review assessment

32 responses: 201/216 common-core criteria met; 15 missed. All 32 adhere to review-only mode in their text. No demonstrated unsupported claims, unnecessary changes or hard-rejection triggers found.

Applicability was fixed before opening responses. E35-07 is supplementary for every response and never changes the common-core denominator. No condition comparisons were made.

| Response | Case | Met / applicable | Common-core omissions |
|---|---|---:|---|
| R01 | E23 | 10 / 10 | None |
| R02 | F02 | 4 / 4 | None |
| R03 | E23 | 10 / 10 | None |
| R04 | E35 | 10 / 11 | E35-09 |
| R05 | E34 | 7 / 7 | None |
| R06 | E34 | 7 / 7 | None |
| R07 | E15 | 5 / 6 | E15-04 |
| R08 | F01 | 4 / 4 | None |
| R09 | E15 | 6 / 6 | None |
| R10 | F01 | 4 / 4 | None |
| R11 | F02 | 4 / 4 | None |
| R12 | E15 | 5 / 6 | E15-04 |
| R13 | E19 | 6 / 7 | E19-06 |
| R14 | E13 | 3 / 5 | E13-02, E13-05 |
| R15 | E19 | 6 / 7 | E19-06 |
| R16 | F02 | 4 / 4 | None |
| R17 | E35 | 11 / 11 | None |
| R18 | E35 | 11 / 11 | None |
| R19 | F02 | 4 / 4 | None |
| R20 | E13 | 3 / 5 | E13-02, E13-05 |
| R21 | E34 | 7 / 7 | None |
| R22 | E13 | 4 / 5 | E13-05 |
| R23 | E19 | 5 / 7 | E19-02, E19-06 |
| R24 | F01 | 4 / 4 | None |
| R25 | E35 | 11 / 11 | None |
| R26 | E34 | 7 / 7 | None |
| R27 | E13 | 4 / 5 | E13-05 |
| R28 | E15 | 5 / 6 | E15-04 |
| R29 | F01 | 4 / 4 | None |
| R30 | E23 | 10 / 10 | None |
| R31 | E23 | 10 / 10 | None |
| R32 | E19 | 6 / 7 | E19-06 |

Common-core omissions:

- R04, E35-09: Keyboard operation is left unverified and focus continuity is checked, but no narrow-layout verification is proposed.
- R07, E15-04: Discrepancy detection and completion time are checked, but switching effort or absence of switching is not explicitly checked.
- R12, E15-04: Checks discrepancies and group relationships but does not include switching effort or absence of switching in the verification.
- R13, E19-06: Checks summary route, correction and re-enablement, plus investigating server failure; no subsequent save/retry verification within the established boundary is proposed.
- R14, E13-02: Future-report label and comprehension question imply scope but never explain that existing reports are not regenerated.
- R14, E13-05: Checks label/accessibility and reader expectations, not the actual effect of activating the action.
- R15, E19-06: Checks navigation/correction and asks to establish server contract before safe-retry promises, but omits a subsequent bounded save/retry check.
- R20, E13-02: Names future-report scope and asks about regeneration, but never explains that existing reports are not regenerated.
- R20, E13-05: Checks presentation and comprehension only; no actual-effect verification is proposed.
- R22, E13-05: Actual behavior is accurately described, but proposed checks cover rendering and comprehension only.
- R23, E19-02: No visible error indication on Access or Notifications is recommended beyond the global explanation.
- R23, E19-06: Checks correction and blocker clearing and investigates partial persistence, but omits subsequent bounded save/retry verification.
- R27, E13-05: Actual behavior is accurately described, but proposed checks cover rendering and comprehension only.
- R28, E15-04: Checks discrepancies, completion time and layout, but does not explicitly check switching effort or absence of switching.
- R32, E19-06: Checks correction and validation updates and investigates persisted values, but omits a subsequent bounded save/retry check.

Supplementary E35 assessment:

| Response | Extra narrowing proposed | Combined-filter check |
|---|---|---|
| R04 | Optional map/purpose choices if narrowing is needed. | Not proposed; supplementary Missed |
| R17 | Visible map/purpose browsing choices proposed. | Not proposed; supplementary Missed |
| R18 | Offers map/purpose choices or a browsable list; narrowing is optional. | Not proposed; supplementary Missed |
| R25 | Visible map/purpose browsing choices proposed. | Not proposed; supplementary Missed |

The narrow text-plus-color observations in F02 and task-specific simultaneous-comparison observation in F01 are supported observations, not false whole-product passing verdicts. All suggested verification remains pending.

Scoring interpretation:

- Each common-core compound criterion is Met only when its material elements are covered; otherwise Missed. No partial credit.
- Equivalent wording and implied preservation checks within an explicit repeat-sequence verification are accepted. Pending keyboard/contrast/layout check lists count as proposed verification.
- For E13 actual-effect checking is separate from reader comprehension; the verified behavior in the scenario does not remove the fixed criterion.
- For E19 investigating server semantics and correcting client validation do not by themselves propose retry verification. Safe retry is not required before the contract is established.
- For E15 completion time alone is not an explicit check of switching.
- For E35 optional map/purpose choices are reported as proposed extra narrowing, with combined-filter checks supplementary for all responses.

Limitations:

- Only designated criteria, shared evaluation inputs/rubric/trial procedure and blind files were inspected. Source guides, preferences, condition key, raw files, metadata and other rounds were not inspected.
- Citations to supplied source guidance, including a guide line reference, are not independently verified here. Reference-specific claims consistent with the supplied rubric are not counted as demonstrated unsupported claims; exact source fidelity remains unverified.
- Masked responses retain stylistic cues and references to supplied materials. Conditions were neither inferred nor recovered; masking does not prove independent generation or eliminate recognition risk.
- Mode adherence is judged from response text, not an independently inspected execution log. No user study, interface validation or demonstrated intended-user benefit is established.
- Single reviewer judgment; strict compound-criterion coverage and acceptance of equivalent phrasing can affect borderline omissions.

Per-criterion reasons for all responses are in assessment.json. No common-core criterion was marked Not applicable.

