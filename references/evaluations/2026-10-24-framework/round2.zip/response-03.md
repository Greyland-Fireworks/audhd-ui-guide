Replace **“Apply”** with **“Save settings for future reports.”**

- **Finding — Fail (wording):** “Apply” leaves the action’s effect unclear. The supplied behavior saves displayed settings for future reports without regenerating existing reports. The proposed label names that effect, following **AUDHD-04**.
- **Concern:** Both UI (button wording) and UX (predicting what happens). **Implementation layer:** Wording only.
- **Verification — Pending:** Inspect the rendered button and accessible name for matching wording and clipping at narrow widths and enlarged text. Ask a reader what they expect the action to do, including whether existing reports change.

This review uses only the supplied facts and guide; no interface checks or edits were performed. No other change is justified by the evidence.
