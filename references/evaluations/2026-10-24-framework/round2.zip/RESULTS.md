# Candidate2 repair/retest results

**Candidate2 passes the nondecreasing aggregate required-finding coverage gate in this fresh masked assessment:** 102/108 (94.44%), versus 99/108 (91.67%) for the preserved baseline responses rescored by the same fresh reviewer. No hard rejection trigger was identified. This is an adaptive repair/retest after the first candidate failed; the original failure remains preserved separately.

| Case | Baseline met/applicable | Candidate2 met/applicable |
|---|---:|---:|
| E13 — wording scope | 6/10 | 8/10 |
| E15 — expert density | 11/12 | 10/12 |
| E19 — hidden validation | 11/14 | 12/14 |
| E23 — invalid/unsupported profiles | 20/20 | 20/20 |
| E34 — pending work | 14/14 | 14/14 |
| E35 — recognition discovery | 21/22 | 22/22 |
| F01 — quick review routing | 8/8 | 8/8 |
| F02 — screenshot-only evidence | 8/8 | 8/8 |
| **Total** | **99/108** | **102/108** |

The prior E34 focus-continuity omission is repaired in both new responses: they recommend preserving focus and explicitly verify it through skin application and pending-save transitions. Candidate2 gains two E13 findings for explicitly stating that existing reports do not regenerate, one E19 group-error-indicator finding, and one E35 narrow-layout-check finding. It loses one finding in aggregate E15 comparison: both candidate2 repeats omit an explicit check of switching effort or absence of switching, versus one baseline omission. This case-level regression remains recorded despite the aggregate gate passing.

All four E13 responses omit actual-effect verification, distinct from expected-meaning checks. All four E19 responses omit completing/retrying the save after correcting client validation within established server boundaries. Both candidate2 E15 responses and one baseline response omit an explicit switching check. One baseline E19 response omits a group/tab error marker; baseline E35 repeat1 omits a narrow-layout check. Criterion-level reasons and raw excerpts are retained in `assessment.json`/`assessment.md`; no response was coached or replaced.

Primary applicability was fixed from the supplied case facts before the reviewer opened any response. E35 establishes one retained query, so combined-filter checking was supplementary for every response rather than changing the primary denominator based on recommendations. All four E35 responses proposed optional or definite map/purpose narrowing choices and omitted combined-filter verification. Adding this supplementary missed criterion equally yields baseline 99/110 and candidate2 102/110; the gate direction remains unchanged.

**Reviewer variation matters.** The same unchanged baseline responses scored 102/108 in the original review's common-denominator sensitivity, versus 99/108 here. The fresh reviewer applied stricter compound criteria: two E13 responses did not explicitly explain no regeneration (a future-report label and comprehension question were not enough), and one E15 response did not explicitly check switching. The atomic criterion list was unchanged, but judgment differed. Original scores were not overwritten, and cross-round candidate scores should not be read as a precise measured improvement. The within-round comparison uses one reviewer applying the same fixed criteria to both conditions.

| Other measure | Baseline | Candidate2 |
|---|---:|---:|
| Review-only mode adherence | 16/16 | 16/16 |
| Unsupported claims identified | 0 | 0 |
| Unnecessary changes identified | 0 | 0 |
| Hard rejection triggers identified | 0 | 0 |
| Total whitespace words | 4,555 | 4,665 |
| Mean words/response | 284.69 | 291.56 |
| Median words/response | 271.5 | 275 |
| Range | 127–432 | 105–478 |

Candidate2 is 110 whitespace words (2.4%) longer in aggregate. These counts include Markdown/table tokens; they are descriptive, not model token counts. No latency, cost or statistical benefit claim is supported. Narrow F02 text-plus-color observations and a narrow F01 simultaneous-comparison observation were judged supported, not whole-product passing verdicts.

The round generated 16 new fresh-context candidate responses, using identical original prompts and inherited settings, two agents concurrently per case; it reused the preserved baseline16. All candidate source hashes stayed stable. Exact model version, sampling settings, tokens and individual duration remain unknown. Raw final responses, prompts, source snapshots/hashes, fixed applicability plan, blind copies, private key, assessments and decoded results are included in the evidence archive. Raw local links are preserved; only blind copies normalize guide-link prefixes.

The fresh reviewer was condition-masked and saw no earlier outcomes. It knew the rubric and procedure; the coordinator knew conditions, and prose may reveal style clues. This is one model reviewer, not independent double-blind research. Mode compliance was judged from text rather than independently audited execution logs. Two repeats per cell, baseline reuse and adaptive repair/retest do not establish generalizability, accessibility conformance, or intended-user benefit.
