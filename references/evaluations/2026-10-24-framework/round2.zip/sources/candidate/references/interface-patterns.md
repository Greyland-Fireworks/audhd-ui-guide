# Interface-pattern lookup

Use the task, not the component name alone, to select checks. Read the linked [Guide rules](../GUIDE.md#ux-and-interaction-rules) when applicable; these prompts do not redefine them. Techniques are optional and findings require evidence.

| Interface family and task | Rules | Questions to investigate | Our example | Evidence needed |
|---|---|---|---|---|
| Forms/settings: change a value and understand its effect | AUDHD-04, 06, 09, 11, 13 | What takes effect, when, and how is failure recovered? | [Unlock-to-edit](../examples/unlock-to-edit/README.md) preserves a restoration point | Actual save contract, rendered labels, keyboard and failure transitions |
| Dashboards: choose what needs attention | AUDHD-01, 02, 07, 08 | Are scope and freshness clear? Can needed values be compared together? | [Skin preview](../examples/skins/README.md) includes labeled charts and data tables | Real task priorities, data meaning and rendered states |
| Navigation/nested views: leave and return | AUDHD-01, 05, 10, 11 | Does the destination match its ancestry? Do drafts and focus survive? | [Recording workspace](../examples/recording-review/README.md) retains local views | Route identities, history, keyboard and return checks |
| Collections/search: find an item without recalling an identifier | AUDHD-03, 04, 05, 10 | Are restrictions visible? Does reset preserve the loaded draft? | [Recognition example](../EXAMPLES.md#find-a-recording-without-remembering-its-identifier) | Available metadata, filter semantics, zero results and unsaved-work transitions |
| Multi-step tasks: understand progress and remaining work | AUDHD-01, 04, 06, 10 | Is completion real? Can the user return to correct a step? | Recording import preview → apply → export is a bounded sequence, not a mandatory wizard | Actual steps, cancellation, failed transitions and return behavior |
| Dialogs/consequential actions: inspect before committing | AUDHD-04, 05, 09, 11, 13 | Is added friction justified? Are effects and recovery accessible? | Unlock-to-edit uses local safeguards rather than mandatory dialogs | Consequences, focus transitions, permission and restoration contracts |
| Loading/empty/error/completion: understand the current result | AUDHD-04, 06, 07, 11 | Is missing data distinct from zero? Are newer edits still unsaved? | Recording review distinguishes earlier acknowledgment from the current draft | Observed pending, failure, retry, stale completion and empty states |

Report the observed problem and consequence, evidence/location, focused proposal, and verification/uncertainty. A screenshot cannot prove persistence or keyboard behavior. Preserve useful density, existing conventions and working controls when no problem is evidenced.
