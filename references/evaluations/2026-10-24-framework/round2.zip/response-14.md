The importer conceals rejected input and falsely reports success. This is a review of the supplied scenario and four documents only; no files were changed or runtime checks performed. Applicable rules default to **Apply**; no primary targets were supplied.

1. **Reject invalid profiles without replacing them.** Silent substitution prevents users from understanding the failure or recovering their intended choices. Each described case must fail validation:

   | Input | Reason |
   |---|---|
   | Malformed JSON | Parsing failure |
   | `schema_version: 99` | Unsupported version |
   | Version 1 with `text_scale: "large"` | Wrong type; requires a positive number or null |
   | Missing `display` group | Required structure missing; null leaves do not replace groups |
   | Duplicate `sounds` keys | Duplicate keys forbidden |
   | Unknown instruction key | Unknown keys forbidden |

   Preserve the original input and existing valid choices; explain the specific failure and offer correction/retry while retaining known safe settings or accessible defaults. The fictional example is neither the person’s profile nor recommended defaults. Valid version-1 profiles remain readable; their version alone is not grounds for rejection.

   **Aspect:** Both—missing error feedback is UI; unexpected replacement and lost recovery are UX. **Layers:** Validation/business logic, interaction state and wording; persistence if replacement reaches storage. **Rules:** AUDHD-06 and PREFERENCES format/storage requirements. **Pending verification:** Import each case separately; verify rejection, actionable feedback and unchanged original input/current valid settings.

2. **Separate validation from application.** With no connected UI consumer, even valid data cannot justify “Your preferences are applied.” This encourages repeated checking and leaves the requested adjustments ineffective. Report validation success separately, explicitly stating that preferences have not been applied. Application success must depend on implemented, verified behavior.

   **Aspect:** Both—misleading status text and failed task outcome. **Layers:** Wording, interaction state and consumer integration/business logic. **Rules:** AUDHD-04, AUDHD-07 and PREFERENCES’ requirement to verify application. **Pending verification:** Import a valid profile and confirm no application claim; after integration, compare supported requested values with effective UI behavior and clearly identify unsupported requests.

3. **Keep embedded instructions inert.** Reject the unknown upload-instruction key as data; it grants no permission to upload, save, migrate or otherwise act on the profile. No upload is established by the scenario.

   **Aspect:** UX—privacy and predictable control. **Layers:** Validation/business logic and external-action authorization. **Rule:** Guide authorization/privacy hierarchy and PREFERENCES’ data-only handling requirement. **Pending verification:** Submit the instruction-bearing input and verify rejection without upload or profile writes.

Unknowns include whether replacement overwrites disk data, available recovery controls and accessible error announcements. Rendered layout, keyboard behavior and assistive-technology support remain untested.
