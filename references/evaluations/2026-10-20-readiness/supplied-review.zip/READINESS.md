# AuDHD UI Guide: bounded release-readiness review

Review date: October 20, 2026 (America/New_York client date).

## Judgment

Suitable for a clearly labeled public beta after rebuilding the release from the intended current source. Not yet demonstrated reliable for general-purpose interface implementation. This is an engineering judgment, not an OpenAI submission decision or accessibility certification.

## Model review trials

Six fresh subagent contexts received the exact standard review request, one scenario, and copies of installed SKILL.md and GUIDE.md. E26 and E34 also received PREFERENCES.md and preferences.example.json. No reviewer rubric or worked examples were supplied. First responses were reviewed by the parent agent against EVALUATION_RUBRIC.md. Separate contexts reduce answer leakage; this remains a small, same-system sample, not independent human review. The evaluator processes inherited the parent model; the tool did not expose a precise model build or sampling settings. No without-skill baseline or repeated trials were run. These were explicit-review trials, not implicit activation tests.

Standard request: Review this fictional interface using the supplied guide. Do not edit anything. Use only the supplied facts; identify unknowns. Distinguish UI concerns, UX concerns or both, separately from the affected implementation layer. Recommend focused changes only where justified. Connect each finding to the user's difficulty, a relevant rule and a concrete verification step. Do not claim checks you have not performed.

| Case | Assessment | Observed response |
|---|---|---|
| E03: code-shaped help | Meets core criteria | Explains unsaved preview inputs, no save/publish effect, non-hover access, and pending scope/comprehension checks. |
| E07: working control | Meets core criteria | Recommends no change, attributes checks to supplied evidence, avoids a redundant confirmation or redesign. |
| E08: unknown undo boundary | Meets core criteria | Precisely names replacement of the draft; neither promises undo nor asserts irreversibility; stays within wording review. |
| E26: appearance and system constraints | Meets core criteria | Honors forced colors, temporary light/larger-text requests, no profile write, no global opacity reduction, and honest effective-state reporting. |
| E34: pending save and profile application | Meets core criteria | Preserves save snapshot versus newer edits, filters, Details, focus and scroll; rejects permanent-storage claims and exporting review notes. |
| E35: recognition-based discovery | Mostly meets criteria | Addresses recognizable metadata, visible search/count/reset, excluded current item and unsaved-note continuity. Keyboard/narrow layouts are acknowledged as unverified, but their concrete test sequences are less explicit than the rubric requests. |

No fabricated executed tests or unauthorized mutations appeared in these six first review responses. This does not establish suitability of their proposed designs or future implementation reliability. The other 29 authored scenarios remain unrun. Exact first responses and exact scenario inputs are included alongside this report. No skill source files were modified.

## Local checks actually executed

- Installed documentation checker: PASS; 22 public Markdown files, relative links/anchors, 13 rule IDs, 35 scenario contracts.
- Release ZIP documentation checker: PASS with the same summary.
- Palette checker: PASS; 22 skins, 11 light/11 dark, configured text/control/focus/series contrast and sequential scales. This checks reference palette data, not the inline demo or all rendered states.
- Unit command: 8 reference state/navigation tests passed. Preference tests could not load because the declared ajv dependency was absent. jsonc-parser is also absent. This is an environment/dependency gap, not evidence of a preference implementation defect. The complete suite did not pass in this environment.
- Browser execution: unavailable in the preceding demonstration because Playwright's Chromium executable is absent. No rendered UI, keyboard, forced-colors, enlarged-text, screen-reader or end-to-end browser success is claimed here.
- ZIP integrity: PASS; 88 entries, no absolute/traversing archive paths, manifest and skills/assets at appropriate root locations. This is bounded inspection, not a comprehensive security scan.
- Release skill icon files are declared as PNGs. Release agent metadata contains no invalid product policy. The installed metadata instead lists lowercase chatgpt/codex/api/atlas; that installed copy does not match the current submission specification, but this is NOT a blocker in ZIP 1.1.1.

## Release mismatch

The actual audhd-ui-guide-1.1.1.zip differs from the installed skill. After normalizing line endings, GUIDE.md, PREFERENCES.md and both evaluation documents match. SKILL.md differs: the installed version includes explicit skill-resource discovery, canonical identifiers, executor fallback and accurate error reporting; ZIP 1.1.1 has only relative-reference loading advice. Thus these six trials directly evaluate installed instructions, not exactly the release snapshot. The changed loader paragraph was not exercised by these copied-file review trials.

ZIP SHA256: e6221276b2b5c7a8edbfc8d369d757e0643d5bfba7efdaf4a54d636bd6669cea

Installed document byte SHA256 values:

- SKILL.md: e55e31636f13b3a32b8e8d4eda69c06f03db0109ed6abbeb3853efcf27cb34fd
- GUIDE.md: 1d74b5d0f15114f5204ff553f4259d481aa25323bee78e3aaecbbad780b3c3dd
- PREFERENCES.md: 559e401640c431901f1d54cbece91c69c7fddd481591fab16593d1c39c448b17
- EVALUATION_INPUTS.md: 3317f43c7df8962567d0e9620b420b86f166494d685aa082709beb2439b2722b
- EVALUATION_RUBRIC.md: bb009eea8d6724fe83be9b9639223bcf25dfd636f22481f4610db58e6a41162a

## Observed implementation failure remains part of the evidence

In the current conversation the generated demonstration's Light appearance was reported unreadable by the user. A CSS correction was proposed without rendered verification. The inherited-color explanation remains a hypothesis. Contrast calculations on intended palette pairs did not establish rendered readability. This failure is not erased by six successful description reviews; it demonstrates the distinction between knowing the rules and reliably implementing/checking them.

## Recommended release gate

1. Rebuild a versioned ZIP from one authoritative source, including current resource-loading guidance, and verify source/package agreement. Keep valid release metadata; do not copy the installed product policy into it.
2. Install that exact ZIP in a fresh ChatGPT context and verify guide/preference resource reads. Test direct audit, an indirect design request, an unrelated prompt and a quoted audit trigger. These activation tests remain pending.
3. In an environment with a browser runtime and declared dependencies, complete one bounded editing workflow: edit, fail save, retry, interrupt/return and switch appearance with an unsaved edit. Inspect light/dark, 320px, enlarged text, keyboard, help and forced colors; separately record assistive-technology coverage.
4. Preserve these failures and results in release notes. Do not describe the skill as proven to generate accessible interfaces. A beta label and clear evidence limits are proportionate; all 35 text cases need not block a practitioner beta.

No upload, submission, publication, source edit or release rebuild was performed by this review.

## Official documentation checked

- https://learn.chatgpt.com/docs/build-skills — skills package instructions/resources; public installation distribution through plugins.
- https://developers.openai.com/plugins/deploy/submission — upload/review/publication process and skills-only distinctions.
- https://developers.openai.com/plugins/deploy/submission-errors — skill agent metadata and product identifiers CHAT/CODEX.

Portal validation and actual client installation remain separate from local checks.
